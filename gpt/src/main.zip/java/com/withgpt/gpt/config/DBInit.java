package com.withgpt.gpt.config;

import com.withgpt.gpt.model.*;
import com.withgpt.gpt.repository.CommentRepository;
import com.withgpt.gpt.repository.PostRepository;
import com.withgpt.gpt.repository.UserRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Configuration
public class DBInit {

    @Bean
    public CommandLineRunner initDatabase(UserRepository userRepository, PostRepository postRepository, CommentRepository commentRepository) {
        return args -> {
            // User 생성
            User user1 = new User();
            user1.setEmail("poet@example.com");
            user1.setName("Poet");
            user1.setAge(25);
            user1.setPhoneNumber("010-1234-5678");
            user1.setBirthday(LocalDate.of(1998, 1, 1));
            user1.setGender(Gender.MALE);
            user1.setPassword("encodedPassword"); // 적절히 암호화된 비밀번호 설정
            userRepository.save(user1);

            // Post 생성 (시, 소설, 에세이, 일기 각각 하나씩)
            Post poetryPost = new Post();
            poetryPost.setTitle("시 제목");
            poetryPost.setContent("시 내용");
            poetryPost.setAuthor(user1);
            poetryPost.setCategory(PostCategory.POETRY);
            poetryPost.setLikeCount(0);
            poetryPost.setViewCount(0);
            poetryPost.setCreatedAt(LocalDateTime.now()); // LocalDateTime으로 수정
            postRepository.save(poetryPost);

            // 댓글 생성 (poetryPost에 대한 댓글)
            Comment comment1 = new Comment();
            comment1.setPost(poetryPost);
            comment1.setAuthor(user1);
            comment1.setContent("이것은 시에 대한 첫 댓글입니다.");
            commentRepository.save(comment1);

            // 나머지 게시글들도 동일하게 생성 가능
        };
    }
}
