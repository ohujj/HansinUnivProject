package com.withgpt.gpt.controller;

import com.withgpt.gpt.model.Post;
import com.withgpt.gpt.model.PostCategory;
import com.withgpt.gpt.service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/posts")
public class PostController {

    @Autowired
    private PostService postService;

    @GetMapping("/{category}")
    public String getPostsByCategory(@PathVariable("category") String categoryStr,
                                     @RequestParam(name = "page", defaultValue = "0") int page,
                                     @RequestParam(name = "size", defaultValue = "10") int size,
                                     Model model) {
        PostCategory category = PostCategory.valueOf(categoryStr.toUpperCase());
        Page<Post> posts = postService.getPostsByCategory(category, PageRequest.of(page, size));
        model.addAttribute("posts", posts.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", posts.getTotalPages());
        model.addAttribute("category", category);
        return "list"; // list.html 템플릿 반환
    }


    @PostMapping("/like/{id}")
    public String likePost(@PathVariable("id") Long postId, @RequestParam("category") PostCategory category) {
        postService.likePost(postId);
        return "redirect:/posts/" + category.toString().toLowerCase();
    }

    @GetMapping("/search")
    public String searchPosts(@RequestParam("keyword") String keyword,
                              @RequestParam(defaultValue = "0") int page,
                              @RequestParam(defaultValue = "10") int size,
                              Model model) {
        Page<Post> posts = postService.searchPostsByKeyword(keyword, PageRequest.of(page, size));
        model.addAttribute("posts", posts.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", posts.getTotalPages());
        model.addAttribute("keyword", keyword);
        return "list";
    }

    @GetMapping("/search/author")
    public String searchByAuthorName(@RequestParam("name") String authorName,
                                     @RequestParam(defaultValue = "0") int page,
                                     @RequestParam(defaultValue = "10") int size,
                                     Model model) {
        Page<Post> posts = postService.searchPostsByAuthorName(authorName, PageRequest.of(page, size));
        model.addAttribute("posts", posts.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", posts.getTotalPages());
        model.addAttribute("authorName", authorName);
        return "list";
    }
}
