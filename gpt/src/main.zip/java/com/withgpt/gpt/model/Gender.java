package com.withgpt.gpt.model;

public enum Gender {
    MALE,
    FEMALE
}
