package com.withgpt.gpt.model;

public enum PostCategory {
    POETRY,
    NOVEL,
    ESSAY,
    DIARY
}
